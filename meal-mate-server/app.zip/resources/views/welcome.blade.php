<?php header("Access-Control-Allow-Origin: *"); ?>
<h3 style="text-align: center; padding: 50px 0px;">Welcome to <a href="https://www.techzaint.com">TechZaint</a></h3>
<h3 style="text-align: center">.!.!.!.</a></h3>